import React, { useState, useMemo } from 'react'
import { PlusCircle, Search, Download, Trash2, Pencil, RotateCcw } from 'lucide-react'

const PAGE_SIZE = 8

export default function Transactions({ transactions, onAddClick, onEditClick, onDeleteClick }) {
  // Filter states
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [typeFilter, setTypeFilter] = useState('all') // 'all' | 'income' | 'expense'
  const [currentPage, setCurrentPage] = useState(1)

  // Clear filters handler
  const handleClearFilters = () => {
    setSearch('')
    setCategory('All')
    setDateFrom('')
    setDateTo('')
    setTypeFilter('all')
    setCurrentPage(1)
  }

  // Filter transactions
  const filteredTransactions = useMemo(() => {
    const query = search.toLowerCase().trim()
    
    return transactions
      .filter(t => {
        // Type Filter
        if (typeFilter !== 'all' && t.type !== typeFilter) return false
        
        // Category Filter
        if (category !== 'All' && t.category !== category) return false
        
        // Date From Filter
        if (dateFrom && t.date < dateFrom) return false
        
        // Date To Filter
        if (dateTo && t.date > dateTo) return false
        
        // Search Term Filter
        if (query) {
          const content = `${t.title} ${t.category} ${t.notes || ''} ${t.payment || ''}`.toLowerCase()
          if (!content.includes(query)) return false
        }
        
        return true
      })
      .sort((a, b) => new Date(b.date) - new Date(a.date))
  }, [transactions, search, category, dateFrom, dateTo, typeFilter])

  // Pagination calculations
  const total = filteredTransactions.length
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE))
  
  // Keep page index within bounds
  const activePage = currentPage > totalPages ? totalPages : currentPage
  
  const startIndex = (activePage - 1) * PAGE_SIZE
  const pageTransactions = useMemo(() => {
    return filteredTransactions.slice(startIndex, startIndex + PAGE_SIZE)
  }, [filteredTransactions, startIndex])

  // Summaries of current filtered records
  const filteredSummary = useMemo(() => {
    let incomeSum = 0
    let expenseSum = 0
    filteredTransactions.forEach(t => {
      if (t.type === 'income') incomeSum += t.amount
      else expenseSum += t.amount
    })
    return { incomeSum, expenseSum }
  }, [filteredTransactions])

  // Format Helpers
  const formatMoney = (val) => {
    return '₹' + Number(val).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  }

  const formatDate = (dateStr) => {
    if (!dateStr) return ''
    return new Date(dateStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
  }

  // Export CSV handler
  const handleExportCSV = () => {
    if (filteredTransactions.length === 0) {
      alert("No transactions found to export.")
      return
    }
    const headers = ["Type", "Title", "Amount (Rs)", "Category", "Payment Method", "Notes", "Date"]
    const csvRows = [
      headers.join(','),
      ...filteredTransactions.map(t => [
        t.type.toUpperCase(),
        `"${t.title.replace(/"/g, '""')}"`,
        t.amount,
        t.category,
        t.payment || 'N/A',
        `"${(t.notes || '').replace(/"/g, '""')}"`,
        t.date
      ].join(','))
    ]
    const csvContent = "data:text/csv;charset=utf-8," + csvRows.join("\n")
    const encodedUri = encodeURI(csvContent)
    const link = document.createElement("a")
    link.setAttribute("href", encodedUri)
    link.setAttribute("download", `spendwise_export_${new Date().toISOString().split('T')[0]}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="view">
      <header className="page-head">
        <h1>Transaction List</h1>
        <div className="head-actions">
          <div style={{ position: 'relative' }}>
            <input 
              type="text" 
              className="search" 
              placeholder="Search title, notes..." 
              value={search}
              onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
              style={{ paddingLeft: '34px' }}
            />
            <Search size={14} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--muted)' }} />
          </div>
          <button className="btn btn-ghost" onClick={handleExportCSV}>
            <Download size={14} /> Export CSV
          </button>
          <button className="btn btn-primary" onClick={onAddClick}>
            <PlusCircle size={14} /> Add transaction
          </button>
        </div>
      </header>

      {/* FILTER PILLS */}
      <div className="type-filter">
        <button 
          className={`type-pill ${typeFilter === 'all' ? 'active-all' : ''}`}
          onClick={() => { setTypeFilter('all'); setCurrentPage(1); }}
        >
          All
        </button>
        <button 
          className={`type-pill ${typeFilter === 'income' ? 'active-income' : ''}`}
          onClick={() => { setTypeFilter('income'); setCurrentPage(1); }}
        >
          🟢 Income
        </button>
        <button 
          className={`type-pill ${typeFilter === 'expense' ? 'active-expense' : ''}`}
          onClick={() => { setTypeFilter('expense'); setCurrentPage(1); }}
        >
          🔴 Expense
        </button>
      </div>

      <div className="panel">
        {/* TOOLBAR FILTERS */}
        <div className="toolbar">
          <label>
            Category
            <select 
              value={category} 
              onChange={(e) => { setCategory(e.target.value); setCurrentPage(1); }}
            >
              <option value="All">All categories</option>
              <option value="Food">Food</option>
              <option value="Transport">Transport</option>
              <option value="Shopping">Shopping</option>
              <option value="Bills">Bills</option>
              <option value="Entertainment">Entertainment</option>
              <option value="Salary">Salary</option>
              <option value="Other">Other</option>
            </select>
          </label>
          <div className="toolbar-divider"></div>
          <label>
            From
            <input 
              type="date" 
              value={dateFrom}
              onChange={(e) => { setDateFrom(e.target.value); setCurrentPage(1); }}
            />
          </label>
          <label>
            To
            <input 
              type="date" 
              value={dateTo}
              onChange={(e) => { setDateTo(e.target.value); setCurrentPage(1); }}
            />
          </label>
          <button className="btn btn-ghost btn-sm" onClick={handleClearFilters}>
            <RotateCcw size={12} /> Clear Filters
          </button>
        </div>

        {/* DATA TABLE */}
        <div className="table-wrapper">
          <table className="table">
            <thead>
              <tr>
                <th>Type</th>
                <th>Title</th>
                <th>Amount</th>
                <th>Category</th>
                <th>Payment</th>
                <th>Notes</th>
                <th>Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {total === 0 ? (
                <tr>
                  <td colSpan={8} className="empty">
                    No transactions match the selected filters.
                  </td>
                </tr>
              ) : (
                pageTransactions.map(t => (
                  <tr key={t.id}>
                    <td>
                      <span className={`pill pill-${t.type}`}>
                        {t.type === 'income' ? 'Income' : 'Expense'}
                      </span>
                    </td>
                    <td><strong>{t.title}</strong></td>
                    <td className={`amt-${t.type}`}>
                      {t.type === 'expense' ? '−' : '+'}{formatMoney(t.amount)}
                    </td>
                    <td>{t.category}</td>
                    <td>{t.payment || '−'}</td>
                    <td className="notes-cell" title={t.notes || ''}>
                      {t.notes || '−'}
                    </td>
                    <td>{formatDate(t.date)}</td>
                    <td>
                      <div className="row-actions">
                        <button 
                          className="icon-btn icon-edit" 
                          onClick={() => onEditClick(t.id)}
                          title="Edit"
                        >
                          <Pencil size={13} />
                        </button>
                        <button 
                          className="icon-btn icon-delete" 
                          onClick={() => onDeleteClick(t.id)}
                          title="Delete"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION AND SUMMARY ROW */}
        {total > 0 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px', marginTop: '16px' }}>
            <div style={{ fontSize: '13px', color: 'var(--muted)' }}>
              Showing {startIndex + 1}–{Math.min(startIndex + PAGE_SIZE, total)} of {total} transactions
            </div>
            
            <div className="pagination">
              <button 
                className="page-btn" 
                disabled={activePage === 1} 
                onClick={() => setCurrentPage(prev => prev - 1)}
              >
                ‹
              </button>
              {Array.from({ length: totalPages }).map((_, idx) => (
                <button 
                  key={idx}
                  className={`page-btn ${activePage === idx + 1 ? 'active' : ''}`}
                  onClick={() => setCurrentPage(idx + 1)}
                >
                  {idx + 1}
                </button>
              ))}
              <button 
                className="page-btn" 
                disabled={activePage === totalPages} 
                onClick={() => setCurrentPage(prev => prev + 1)}
              >
                ›
              </button>
            </div>
          </div>
        )}

        {total > 0 && (
          <div style={{ marginTop: '16px', fontSize: '13px', color: 'var(--muted)', textAlign: 'right', borderTop: '1px solid var(--line)', paddingTop: '12px' }}>
            Filtered Total: &nbsp;
            <span className="amt-income">+{formatMoney(filteredSummary.incomeSum)}</span> Income &nbsp;|&nbsp;
            <span className="amt-expense">−{formatMoney(filteredSummary.expenseSum)}</span> Expense
          </div>
        )}
      </div>
    </div>
  )
}
