import React, { useState, useEffect } from 'react'

export default function TransactionModal({ isOpen, transactionToEdit, onClose, onSave }) {
  const [type, setType] = useState('expense')
  const [title, setTitle] = useState('')
  const [amount, setAmount] = useState('')
  const [category, setCategory] = useState('Food')
  const [payment, setPayment] = useState('Cash')
  const [date, setDate] = useState('')
  const [notes, setNotes] = useState('')

  // Populating form values when editing
  useEffect(() => {
    if (transactionToEdit) {
      setType(transactionToEdit.type || 'expense')
      setTitle(transactionToEdit.title || '')
      setAmount(transactionToEdit.amount || '')
      setCategory(transactionToEdit.category || 'Food')
      setPayment(transactionToEdit.payment || 'Cash')
      setDate(transactionToEdit.date || '')
      setNotes(transactionToEdit.notes || '')
    } else {
      setType('expense')
      setTitle('')
      setAmount('')
      setCategory('Food')
      setPayment('Cash')
      setDate(new Date().toISOString().split('T')[0])
      setNotes('')
    }
  }, [transactionToEdit, isOpen])

  if (!isOpen) return null

  const handleSubmit = (e) => {
    e.preventDefault()

    const cleanTitle = title.trim()
    const parsedAmount = parseFloat(amount)
    const cleanNotes = notes.trim()

    if (!cleanTitle || isNaN(parsedAmount) || parsedAmount <= 0 || !date) {
      alert("Please fill in a valid title, positive amount, and date.")
      return
    }

    const payload = {
      id: transactionToEdit ? transactionToEdit.id : null,
      type,
      title: cleanTitle,
      amount: parsedAmount,
      category,
      payment,
      date,
      notes: cleanNotes
    }

    onSave(payload)
  }

  // Handle clicking backdrop to close modal
  const handleBackdropClick = (e) => {
    if (e.target.className === 'modal-backdrop') {
      onClose()
    }
  }

  return (
    <div className="modal-backdrop" onClick={handleBackdropClick}>
      <div className="modal">
        <h3>{transactionToEdit ? 'Edit Transaction' : 'Add Transaction'}</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <label>
              Type
              <select value={type} onChange={(e) => setType(e.target.value)}>
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </select>
            </label>

            <label>
              Title
              <input 
                type="text" 
                placeholder="e.g. Groceries"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </label>

            <label>
              Amount (₹)
              <input 
                type="number" 
                placeholder="e.g. 500"
                min="0.01"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </label>

            <label>
              Category
              <select value={category} onChange={(e) => setCategory(e.target.value)}>
                <option value="Food">Food</option>
                <option value="Transport">Transport</option>
                <option value="Shopping">Shopping</option>
                <option value="Bills">Bills</option>
                <option value="Entertainment">Entertainment</option>
                <option value="Salary">Salary</option>
                <option value="Other">Other</option>
              </select>
            </label>

            <label>
              Payment Method
              <select value={payment} onChange={(e) => setPayment(e.target.value)}>
                <option value="Cash">Cash</option>
                <option value="Card">Card</option>
                <option value="UPI">UPI</option>
                <option value="Online">Online</option>
              </select>
            </label>

            <label>
              Date
              <input 
                type="date" 
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
              />
            </label>

            <label className="full">
              Notes
              <textarea 
                placeholder="Optional description..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </label>
          </div>

          <div className="modal-actions">
            <button type="button" className="btn btn-ghost" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Save Transaction
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
