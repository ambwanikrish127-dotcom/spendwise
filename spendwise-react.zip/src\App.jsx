import React, { useState, useEffect } from 'react'
import Sidebar from './components/Sidebar'
import Dashboard from './components/Dashboard'
import Transactions from './components/Transactions'
import Reports from './components/Reports'
import TransactionModal from './components/TransactionModal'

// Safe helper for localStorage loading
const loadTransactions = () => {
  try {
    const raw = localStorage.getItem('transactions')
    return raw ? JSON.parse(raw) : []
  } catch (e) {
    console.error("Failed to load transactions", e)
    return []
  }
}

export default function App() {
  const [transactions, setTransactions] = useState(loadTransactions)
  const [currentView, setView] = useState('dashboard')
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingTransactionId, setEditingTransactionId] = useState(null)

  // Sync state changes with localStorage
  useEffect(() => {
    try {
      localStorage.setItem('transactions', JSON.stringify(transactions))
    } catch (e) {
      console.error("Failed to save transactions", e)
    }
  }, [transactions])

  // Helpers to fetch editing data
  const transactionToEdit = transactions.find(t => t.id === editingTransactionId)

  // Handlers
  const handleSaveTransaction = (data) => {
    if (data.id) {
      // Edit mode
      setTransactions(prev => prev.map(t => t.id === data.id ? { ...t, ...data } : t))
    } else {
      // Create mode
      const newTransaction = {
        ...data,
        id: Date.now().toString() + Math.floor(Math.random() * 1000)
      }
      setTransactions(prev => [...prev, newTransaction])
    }
    setIsModalOpen(false)
    setEditingTransactionId(null)
  }

  const handleDeleteTransaction = (id) => {
    if (window.confirm("Are you sure you want to delete this transaction?")) {
      setTransactions(prev => prev.filter(t => t.id !== id))
    }
  }

  const handleOpenAddModal = () => {
    setEditingTransactionId(null)
    setIsModalOpen(true)
  }

  const handleOpenEditModal = (id) => {
    setEditingTransactionId(id)
    setIsModalOpen(true)
  }

  const handleCloseModal = () => {
    setIsModalOpen(false)
    setEditingTransactionId(null)
  }

  return (
    <div className="app">
      <Sidebar 
        currentView={currentView} 
        setView={setView} 
      />

      <main className="main">
        {currentView === 'dashboard' && (
          <Dashboard 
            transactions={transactions} 
            onAddClick={handleOpenAddModal}
            onEditClick={handleOpenEditModal}
            onDeleteClick={handleDeleteTransaction}
          />
        )}

        {currentView === 'transactions' && (
          <Transactions 
            transactions={transactions}
            onAddClick={handleOpenAddModal}
            onEditClick={handleOpenEditModal}
            onDeleteClick={handleDeleteTransaction}
          />
        )}

        {currentView === 'reports' && (
          <Reports 
            transactions={transactions}
          />
        )}
      </main>

      <TransactionModal 
        isOpen={isModalOpen}
        transactionToEdit={transactionToEdit}
        onClose={handleCloseModal}
        onSave={handleSaveTransaction}
      />
    </div>
  )
}
