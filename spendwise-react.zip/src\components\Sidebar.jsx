import React from 'react'
import { LayoutDashboard, ArrowLeftRight, BarChart3 } from 'lucide-react'

export default function Sidebar({ currentView, setView }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <span className="brand-logo">₹</span>
        <span className="brand-name">SpendWise</span>
      </div>
      <nav className="nav">
        <button 
          className={`nav-item ${currentView === 'dashboard' ? 'active' : ''}`}
          onClick={() => setView('dashboard')}
        >
          <span className="nav-icon"><LayoutDashboard size={18} /></span>
          Dashboard
        </button>
        <button 
          className={`nav-item ${currentView === 'transactions' ? 'active' : ''}`}
          onClick={() => setView('transactions')}
        >
          <span className="nav-icon"><ArrowLeftRight size={18} /></span>
          Transactions
        </button>
        <button 
          className={`nav-item ${currentView === 'reports' ? 'active' : ''}`}
          onClick={() => setView('reports')}
        >
          <span className="nav-icon"><BarChart3 size={18} /></span>
          Reports
        </button>
      </nav>
      <div className="sidebar-foot">React · Vite · Modern CSS</div>
    </aside>
  )
}
