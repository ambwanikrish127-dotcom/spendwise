import React, { useState, useMemo } from 'react'

export default function Reports({ transactions }) {
  // Date range states for reporting
  const [rptFrom, setRptFrom] = useState('')
  const [rptTo, setRptTo] = useState('')
  const [appliedFrom, setAppliedFrom] = useState('')
  const [appliedTo, setAppliedTo] = useState('')

  const handleApplyRange = () => {
    setAppliedFrom(rptFrom)
    setAppliedTo(rptTo)
  }

  const handleShowAll = () => {
    setRptFrom('')
    setRptTo('')
    setAppliedFrom('')
    setAppliedTo('')
  }

  // Filter transactions for reports
  const reportTransactions = useMemo(() => {
    return transactions.filter(t => {
      if (appliedFrom && t.date < appliedFrom) return false
      if (appliedTo && t.date > appliedTo) return false
      return true
    })
  }, [transactions, appliedFrom, appliedTo])

  // Summaries
  const summary = useMemo(() => {
    let income = 0
    let expense = 0
    reportTransactions.forEach(t => {
      if (t.type === 'income') income += t.amount
      else expense += t.amount
    })
    return { income, expense, savings: income - expense }
  }, [reportTransactions])

  // Monthly breakdown
  const monthlyData = useMemo(() => {
    const months = {}
    reportTransactions.forEach(t => {
      if (!t.date) return
      const mLabel = t.date.slice(0, 7) // YYYY-MM
      if (!months[mLabel]) {
        months[mLabel] = { income: 0, expense: 0 }
      }
      months[mLabel][t.type] += t.amount
    })

    return Object.keys(months)
      .sort((a, b) => b.localeCompare(a)) // Reverse chronological order
      .map(mLabel => {
        const { income, expense } = months[mLabel]
        const [yr, mo] = mLabel.split("-")
        const dateObj = new Date(yr, mo - 1, 1)
        const displayLabel = dateObj.toLocaleDateString("en-IN", { month: "long", year: "numeric" })
        return {
          key: mLabel,
          label: displayLabel,
          income,
          expense,
          savings: income - expense
        }
      })
  }, [reportTransactions])

  // Category spending (expense only)
  const categorySpending = useMemo(() => {
    const totals = {}
    reportTransactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        totals[t.category] = (totals[t.category] || 0) + t.amount
      })

    const sortedCats = Object.keys(totals).sort((a, b) => totals[b] - totals[a])
    const maxVal = sortedCats.length > 0 ? totals[sortedCats[0]] : 0

    return sortedCats.map(cat => ({
      category: cat,
      amount: totals[cat],
      percentage: maxVal > 0 ? (totals[cat] / maxVal) * 100 : 0
    }))
  }, [reportTransactions])

  // Helpers
  const formatMoney = (val) => {
    return '₹' + Number(val).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  }

  return (
    <div className="view">
      <header className="page-head">
        <h1>Reports</h1>
      </header>

      {/* DATE RANGE PANEL */}
      <div className="panel">
        <h3>Date Range Analysis</h3>
        <div className="toolbar">
          <label>
            From
            <input 
              type="date" 
              value={rptFrom} 
              onChange={(e) => setRptFrom(e.target.value)} 
            />
          </label>
          <label>
            To
            <input 
              type="date" 
              value={rptTo} 
              onChange={(e) => setRptTo(e.target.value)} 
            />
          </label>
          <button className="btn btn-primary btn-sm" onClick={handleApplyRange}>
            Apply Range
          </button>
          <button className="btn btn-ghost btn-sm" onClick={handleShowAll}>
            Show All
          </button>
        </div>

        <div className="range-summary">
          <div className="range-box">
            <div className="rb-label">Total Income</div>
            <div className="rb-val amt-income">{formatMoney(summary.income)}</div>
          </div>
          <div className="range-box">
            <div className="rb-label">Total Expense</div>
            <div className="rb-val amt-expense">{formatMoney(summary.expense)}</div>
          </div>
          <div className="range-box">
            <div className="rb-label">Savings (Net)</div>
            <div className={`rb-val ${summary.savings >= 0 ? 'savings-positive' : 'savings-negative'}`}>
              {summary.savings >= 0 ? '+' : ''}{formatMoney(summary.savings)}
            </div>
          </div>
        </div>
      </div>

      {/* MONTHLY BREAKDOWN TABLE */}
      <div className="panel">
        <h3>Monthly Breakdown</h3>
        {monthlyData.length === 0 ? (
          <p className="empty">No records found for the selected reporting period.</p>
        ) : (
          <div className="table-wrapper">
            <table className="month-table">
              <thead>
                <tr>
                  <th>Month</th>
                  <th>Income</th>
                  <th>Expense</th>
                  <th>Savings</th>
                </tr>
              </thead>
              <tbody>
                {monthlyData.map(m => (
                  <tr key={m.key}>
                    <td><strong>{m.label}</strong></td>
                    <td className="amt-income">+{formatMoney(m.income)}</td>
                    <td className="amt-expense">−{formatMoney(m.expense)}</td>
                    <td className={m.savings >= 0 ? 'savings-positive' : 'savings-negative'}>
                      {m.savings >= 0 ? '+' : ''}{formatMoney(m.savings)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* SPENDING BY CATEGORY BARS */}
      <div className="panel">
        <h3>Spending by Category</h3>
        {categorySpending.length === 0 ? (
          <p className="empty">No expense records found for this period.</p>
        ) : (
          <div className="report-bars">
            {categorySpending.map(item => (
              <div key={item.category} className="bar-row">
                <div className="bar-label">{item.category}</div>
                <div className="bar-track">
                  <div 
                    className="bar-fill" 
                    style={{ width: `${item.percentage}%`, backgroundColor: 'var(--primary)' }}
                  ></div>
                </div>
                <div className="bar-value">{formatMoney(item.amount)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
