import React from 'react'
import { PlusCircle, Pencil, Trash2 } from 'lucide-react'

export default function Dashboard({ transactions, onAddClick, onEditClick, onDeleteClick }) {
  // Calculations
  const incomeTransactions = transactions.filter(t => t.type === 'income')
  const expenseTransactions = transactions.filter(t => t.type === 'expense')
  
  const totalIncome = incomeTransactions.reduce((acc, t) => acc + t.amount, 0)
  const totalExpense = expenseTransactions.reduce((acc, t) => acc + t.amount, 0)
  const balance = totalIncome - totalExpense

  // Format currency
  const formatMoney = (val) => {
    return '₹' + Number(val).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  }

  // Format date nicely
  const formatDate = (dateStr) => {
    if (!dateStr) return ''
    return new Date(dateStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
  }

  // Sort and pick recent 5
  const recentTransactions = [...transactions]
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 5)

  return (
    <div className="view">
      <header className="page-head">
        <h1>Dashboard</h1>
        <button className="btn btn-primary" onClick={onAddClick}>
          <PlusCircle size={16} /> Add transaction
        </button>
      </header>

      <div className="cards">
        <div className="card card-income">
          <p className="card-label">Total Income</p>
          <h2>{formatMoney(totalIncome)}</h2>
          <p className="card-sub">{incomeTransactions.length} transactions</p>
        </div>
        <div className="card card-expense">
          <p className="card-label">Total Expense</p>
          <h2>{formatMoney(totalExpense)}</h2>
          <p className="card-sub">{expenseTransactions.length} transactions</p>
        </div>
        <div className="card card-balance">
          <p className="card-label">Net Balance</p>
          <h2 style={{ color: balance >= 0 ? 'var(--green)' : 'var(--red)' }}>
            {formatMoney(balance)}
          </h2>
          <p className="card-sub">Income − Expense</p>
        </div>
      </div>

      <div className="panel">
        <h3>Recent Transactions</h3>
        {recentTransactions.length === 0 ? (
          <p className="empty">No transactions logged yet. Click "+ Add transaction" to get started!</p>
        ) : (
          <div className="recent-list">
            {recentTransactions.map(t => (
              <div key={t.id} className="recent-item">
                <div style={{ flex: 1, minWidth: 0, paddingRight: 16 }}>
                  <div className="recent-title">{t.title}</div>
                  <div className="recent-meta">
                    {t.category} · {t.payment || 'N/A'} · {formatDate(t.date)}
                    {t.notes && <span style={{ fontStyle: 'italic', opacity: 0.8 }}> ({t.notes})</span>}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                  <div className={`amt-${t.type}`} style={{ fontSize: '15px', fontWeight: 600 }}>
                    {t.type === 'expense' ? '−' : '+'}{formatMoney(t.amount)}
                  </div>
                  <div className="row-actions">
                    <button 
                      className="icon-btn icon-edit" 
                      onClick={() => onEditClick(t.id)}
                      title="Edit"
                    >
                      <Pencil size={13} />
                    </button>
                    <button 
                      className="icon-btn icon-delete" 
                      onClick={() => onDeleteClick(t.id)}
                      title="Delete"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
